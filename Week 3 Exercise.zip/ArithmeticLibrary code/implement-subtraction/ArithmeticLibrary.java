public class ArithmeticLibrary {

   
   public static int subtract(int a, int b) {
      return a - b;
   }

}