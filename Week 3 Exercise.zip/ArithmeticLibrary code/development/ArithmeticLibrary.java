public class ArithmeticLibrary {

}